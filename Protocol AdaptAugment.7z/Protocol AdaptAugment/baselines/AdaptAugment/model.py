
import pickle
import time
import random
# import matplotlib.pyplot as plt
# plt.figure()
# plt.imshow(supp_x[0,0].numpy())
# plt.show()

TIME_LIMIT = 1 # time limit of the whole process in seconds   4500
TIME_TRAIN = TIME_LIMIT - 30*60 # set aside 30min for test
t1 = time.time()

import os
import torch
import torch.nn as nn


from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import MinMaxScaler
from sklearn.pipeline import Pipeline
from skimage.color import rgb2gray


try:
    import numpy as np
except:
    os.system("pip install numpy")

try:
    import cython
except:
    os.system("pip install cython")

try:
    import ot
except:
    os.system("pip install POT")

try:
    import tqdm
except:
    os.system("pip install tqdm")

try:
    import timm
except:
    os.system("pip install timm")


from torchvision.transforms import functional as TF
from utils import get_logger, timer, resize_tensor, augment, decode_label, decode_label_logits, mean
#from utils2 import  decode_label2
from torch import cat as c
from api import MetaLearner, Learner, Predictor
from backbone import MLP, rn_timm_mix, Wrapper_pf, set_parameters,Wrapper_res,EnsembleWrapper
from lta import lta_f, lta_r, f_lta, r_lta
from torch import optim
import torch.nn.functional as F
from typing import Iterable, Any, Tuple, List
from skimage.transform import rescale, resize
import tensorflow as tf
import keras
import umap
import matplotlib.pyplot as plt
from sklearn.preprocessing import  StandardScaler

from tensorflow.keras.applications.mobilenet import MobileNet
from tensorflow.keras.layers import GlobalAveragePooling2D



from skimage import exposure
import timm
from torchvision.transforms import autoaugment

# --------------- MANDATORY ---------------
SEED = 98
torch.backends.cudnn.deterministic = True
torch.backends.cudnn.benchmark = False
random.seed(SEED)    
torch.manual_seed(SEED)
np.random.seed(SEED)
if torch.cuda.is_available():
    torch.cuda.manual_seed(SEED)
# -----------------------------------------



LOGGER = get_logger('GLOBAL')
DEVICE = torch.device('cuda') # cpu cuda


class GaussianModel():
    def __init__(self, n_ways, device, supp_y):
        self.n_ways = n_ways
        self.device = device
        self.supp_y = supp_y

    def cp(self, embeddings, labels):
        n_way = self.n_ways
        prots = torch.zeros(n_way, embeddings.shape[-1]).type(
            embeddings.dtype).to(embeddings.device)
        for i in range(n_way):
            if torch.__version__.startswith('1.1'):
                prots[i] = embeddings[(labels == i).nonzero(), :].mean(0)
            else:
                prots[i] = embeddings[(labels == i).nonzero(as_tuple=False), :].mean(0)
        return prots

    def to(self, device):
        self.mus = self.mus.to(device)
        
    def compute_prototypes(self, shot_data, labels):
        self.mus = self.cp(shot_data, labels)
        self.mus_origin = shot_data

    def updateFromEstimate(self, estimate, alpha):
        
        Dmus = estimate - self.mus
        self.mus = self.mus + alpha * (Dmus)
    
    def getProbas(self, quer_vec):
        # mus: n_shot * dim
        # quer_vec: n_query * dim
        dist = ot.dist(quer_vec.detach().cpu().numpy(), 
            self.mus.detach().cpu().numpy(), metric="cosine")

        dist=torch.from_numpy(dist).float().to(quer_vec.device)
        
        n_usamples, n_ways = quer_vec.size(0), self.n_ways
        if isinstance(dist, torch.Tensor):
            dist = dist.detach().cpu().numpy()
        p_xj_test = torch.from_numpy(ot.emd(np.ones(n_usamples) / n_usamples, 
            np.ones(n_ways) / n_ways, dist)).float().to(quer_vec.device) * \
            n_usamples
        
        return p_xj_test
    
    def estimateFromMask(self, quer_vec, mask):
        # mask: queries * ways
        # quer_vec: queries * dim

        origin_sum = torch.zeros((self.n_ways, self.mus_origin.shape[1]), dtype=torch.float32)
        for i in range(self.n_ways):
                    origin_sum[i] = self.mus_origin[self.supp_y == i].sum(dim=0)
        return ((mask.permute(1, 0) @ quer_vec) + origin_sum) \
            / (mask.sum(dim=0).unsqueeze(1) + torch.tensor((self.n_ways), dtype=torch.float32))

        # return ((mask.permute(1, 0) @ quer_vec) + self.mus_origin.sum(dim=1)) \
        #     / (mask.sum(dim=0).unsqueeze(1) + self.mus_origin.size(1))


class MAP:
    def __init__(self, alpha, supp_y):
        self.alpha = alpha
        self.supp_y = supp_y
    
    def getAccuracy(self, probas, labels):
        olabels = probas.argmax(dim=1)
        matches = labels.eq(olabels).float()
        acc_test = matches.mean()
        return acc_test
    
    def performEpoch(self, model: GaussianModel, quer_vec, labels):
        m_estimates = model.estimateFromMask(quer_vec, self.probas)
               
        # update centroids
        model.updateFromEstimate(m_estimates, self.alpha)

        self.probas = model.getProbas(quer_vec)
        if labels is not None:
            acc = self.getAccuracy(self.probas, labels)
            return acc
        return 0.

    def loop(self, model: GaussianModel, quer_vec, n_epochs=20, labels=None):
        
        self.probas = model.getProbas(quer_vec)
        acc_list = []
        if labels is not None:
            acc_list.append(self.getAccuracy(self.probas, labels))
           
        for epoch in range(1, n_epochs+1):
            acc = self.performEpoch(model, quer_vec, labels)
            if labels is not None:
                acc_list.append(acc)
        
        return self.probas, acc_list



class MyMetaLearner(MetaLearner):

    def __init__(self,
                 train_classes: int,
                 total_classes: int,
                 logger: Any) -> None:

        super().__init__(train_classes, total_classes, logger)

        self.timer = timer()
        self.timer.initialize(time.time(), TIME_TRAIN - time.time() + t1)
        self.timer.begin('load pretrained model')
        # model1:PoolFormer
        self.model_pf = Wrapper_pf(rn_timm_mix(True, 'poolformer_s24', 0.1)).to(DEVICE)
        # model2:ResNet50
        self.model_res=Wrapper_res(rn_timm_mix(True, 'swsl_resnet50', 0.1)).to(DEVICE)    
        times = self.timer.end('load pretrained model')
        LOGGER.info('current model', self.model_pf)
        LOGGER.info('load time', times, 's')
        self.dim = 1000 

        self.model_res = set_parameters(self.model_res)
        self.model_pf = set_parameters(self.model_pf) 
        self.cls = MLP(self.dim, train_classes).to(DEVICE)
        self.opt = optim.Adam(
            [
                {"params": self.model_pf.parameters()},
                {"params": self.cls.parameters(), "lr": 1e-3}
            ], lr=1e-4
        )
        torch.set_num_threads(4)

    def meta_fit(self,
                 meta_train_generator: Iterable[Any],
                 meta_valid_generator: Iterable[Any]) -> Learner:

        # fix the valid dataset for fair comparison
        valid_task=[]      
        for task in meta_valid_generator(50):
            supp_x, supp_y = task.support_set[0], task.support_set[1]
            quer_x, quer_y = task.query_set[0], task.query_set[1] 
            supp_x = supp_x[supp_y.sort()[1]]
            supp_end = supp_x.size(0)
            valid_task.append([torch.cat([resize_tensor(supp_x),
                                          resize_tensor(quer_x)]), quer_y])


        total_epoch = 0 

        with torch.no_grad():
            acc_valid = 0
            for x, quer_y in valid_task:
                x = x.to(DEVICE)
                x = self.model_res(x)
                supp_x, quer_x = x[:supp_end], x[supp_end:]
                supp_x = supp_x.view(5, 5, supp_x.size(-1))
                logit = decode_label_logits(supp_x, quer_x).cpu().numpy()
                acc_valid += (logit.argmax(1) == np.array(quer_y)).mean()
            acc_valid /= len(valid_task)
            LOGGER.info("epoch %2d valid mean acc %.6f" % (total_epoch,
                                                           acc_valid))
        best_valid_res = acc_valid
        best_param_res = pickle.dumps(self.model_res.state_dict())

        with torch.no_grad():
            acc_valid = 0
            for x, quer_y in valid_task:
                x = x.to(DEVICE)
                x = self.model_pf(x)
                supp_x, quer_x = x[:supp_end], x[supp_end:]
                supp_x = supp_x.view(5, 5, supp_x.size(-1))
                logit = decode_label_logits(supp_x, quer_x).cpu().numpy()
                acc_valid += (logit.argmax(1) == np.array(quer_y)).mean()
            acc_valid /= len(valid_task)
            LOGGER.info("epoch %2d valid mean acc %.6f" % (total_epoch,
                                                           acc_valid))
        best_valid_pf = acc_valid
        best_param_pf = pickle.dumps(self.model_pf.state_dict())


        self.cls.train()
        while total_epoch <0:
            self.model_pf.train()
            for _ in range(5):
                total_epoch += 1
                self.opt.zero_grad()
                err = 0
                acc = 0
                for i, batch in enumerate(meta_train_generator(10)):
                    self.timer.begin('train data loading')
                    X_train, y_train = batch
                    X_train = augment(X_train)
                    X_train = resize_tensor(X_train).to(DEVICE)
                    y_train = y_train.view(-1).to(DEVICE)
                    self.timer.end('train data loading')

                    self.timer.begin('train forward')
                    feature = self.model_pf(X_train)
                    logit = self.cls(feature)
                    loss = F.cross_entropy(logit, y_train) / 10.
                    self.timer.end('train forward')

                    self.timer.begin('train backward')
                    loss.backward()
                    self.timer.end('train backward')
                    err += loss.item()
                    acc += logit.argmax(1).eq(y_train).float().mean()

                self.opt.step()
                acc /= 10
                LOGGER.info(
                    'epoch %2d error: %.6f acc %.6f | time cost - dataload: %.2f forward: %.2f backward: %.2f' % (
                        total_epoch, err, acc,
                        self.timer.query_time_by_name("train data loading",
                                                      method=lambda x: mean(x[-10:])),
                        self.timer.query_time_by_name("train forward",
                                                      method=lambda x: mean(x[-10:])),
                        self.timer.query_time_by_name("train backward",
                                                      method=lambda x: mean(x[-10:])),
                    ))

            with torch.no_grad():
                acc_valid = 0                
                for x, quer_y in valid_task:
                    x = x.to(DEVICE)
                    x = self.model_res(x)
                    supp_x, quer_x = x[:supp_end], x[supp_end:]
                    supp_x = supp_x.view(5, 5, supp_x.size(-1))
                    logit = decode_label_logits(supp_x, quer_x).cpu().numpy()
                    acc_valid += (logit.argmax(1) == np.array(quer_y)).mean()
                acc_valid /= len(valid_task)
                LOGGER.info("epoch %2d valid mean acc %.6f" % (total_epoch,
                                                               acc_valid))
            if best_valid_res < acc_valid:
                # save the best model
                best_param_res = pickle.dumps(self.model_res.state_dict())
                best_valid_res = acc_valid

            with torch.no_grad():
                acc_valid = 0                
                for x, quer_y in valid_task:
                    x = x.to(DEVICE)
                    x = self.model_pf(x)
                    supp_x, quer_x = x[:supp_end], x[supp_end:]
                    supp_x = supp_x.view(5, 5, supp_x.size(-1))
                    logit = decode_label_logits(supp_x, quer_x).cpu().numpy()
                    acc_valid += (logit.argmax(1) == np.array(quer_y)).mean()
                acc_valid /= len(valid_task)
                LOGGER.info("epoch %2d valid mean acc %.6f" % (total_epoch,
                                                               acc_valid))
            if best_valid_pf < acc_valid:
                best_param_pf = pickle.dumps(self.model_pf.state_dict())
                best_valid_pf = acc_valid
            


        self.model_res.load_state_dict(pickle.loads(best_param_res))
        self.model_pf.load_state_dict(pickle.loads(best_param_pf))
        self.ensemble_model=EnsembleWrapper(self.model_pf,self.model_res)

        return MyLearner(self.ensemble_model.cpu())


class MyLearner(Learner):

    def __init__(self, model: EnsembleWrapper = None) -> None:

        super().__init__()
        if model is None:
            self.model_pf=None
            self.model_res=None  
        else:
            self.model_pf = model.model1
            self.model_res = model.model2
          

    def fit(self, support_set: Tuple[torch.Tensor, torch.Tensor, torch.Tensor,
                                     int, int]) -> Predictor:

        X_train, y_train, _, n, k = support_set
        self.model=EnsembleWrapper(self.model_pf,self.model_res)
        return MyPredictor(self.model, X_train, y_train, n, k)

    def save(self, path_to_save: str) -> None:

        torch.save(self.model_pf, os.path.join(path_to_save, "model1.pt"))
        torch.save(self.model_res, os.path.join(path_to_save, "model2.pt"))

    def load(self, path_to_load: str) -> None:

        if self.model_pf is None:
            self.model_pf=torch.load(os.path.join(path_to_load,"model1.pt"))
        if self.model_res is None:
            self.model_res=torch.load(os.path.join(path_to_load,"model2.pt"))





    
class MyPredictor(Predictor):
    def __init__(self,
                 model,
                 supp_x: torch.Tensor,
                 supp_y: torch.Tensor,
                 n: int,
                 k: int) -> None:

        super().__init__()
        self.f = model.model1
        self.r=model.model2
        baseline = tf.keras.applications.mobilenet.MobileNet(include_top=False, input_shape=(128, 128, 3), weights="imagenet")
        self.m=tf.keras.models.Model(inputs=baseline.inputs, outputs=tf.keras.layers.GlobalAveragePooling2D()(baseline.layers[-1].output))
        self.other = [supp_x, supp_y, n, k]


    def Reshape(self, _X, channels_order):
        if channels_order == 'First':
            np_X = np.array (_X)
            resh_X = np.zeros((np_X.shape[0],np_X.shape[2],np_X.shape[3],3))
            resh_X[:,:,:,0], resh_X[:,:,:,1], resh_X[:,:,:,2] = np_X[:, 0], np_X[:, 1], np_X[:, 2]
            ###_X = tf.convert_to_tensor(resh_X, np.float32)
        elif channels_order == 'Last':
            np_X = np.array (_X)
            resh_X = np.zeros((np_X.shape[0], 3, np_X.shape[1],np_X.shape[2]))
            resh_X[:,0,:,:], resh_X[:,1,:,:], resh_X[:,2,:,:] = np_X[:,:,:,0], np_X[:,:,:,1], np_X[:,:,:,2]
            ###_X = tf.convert_to_tensor(resh_X, np.float32)
        return resh_X


    def augm_add_all(self, X_train, y_train,n,k):

        if k>4 and n>17:
            shape_augm_range = 1 # to avoid gpu memory issues
        elif k>4:
            shape_augm_range = 2
        elif k>3:
            shape_augm_range = 3
        else:
            shape_augm_range = 5

        aug = tf.keras.preprocessing.image.ImageDataGenerator(
            rotation_range=20,
            zoom_range=0.15,
            width_shift_range=0.2,
            height_shift_range=0.2,
            shear_range=0.15,
            horizontal_flip=True, fill_mode="nearest")

        X,y = [],[]
        for image, label in zip(X_train, y_train):

                    ### Texture
                    highB = np.array(image) + (100/255) # 1
                    highC = np.array(image) * 3         # 2
                    gray_scale_image = np.array(image)  # 3
                    _ = rgb2gray(np.array(image))
                    gray_scale_image[:,:,0], gray_scale_image[:,:,1], gray_scale_image[:,:,2] = _, _, _
                    v_min, v_max = np.percentile(np.array(image), (0.2, 99.8))  # 4
                    better_contrast = exposure.rescale_intensity(np.array(image), in_range=(v_min, v_max))
                    adjusted_gamma_image = exposure.adjust_gamma(np.array(image), gamma=0.4, gain=0.9) # 5
                    image_aug_texture = [highB, highC, gray_scale_image, better_contrast, adjusted_gamma_image] # [1,2,3,4,5]
                    texture_augm_range = len(image_aug_texture)

                    ### Shape
                    image = np.expand_dims(image, 0)
                    image_aug_shape = aug.flow(image, batch_size=1)
                    image_aug_shape = [image_aug_shape.next() for i in range(shape_augm_range)]

                    for n in range(shape_augm_range):
                        X += [image_aug_shape[n]]
                        y += [label]

                    n = np.random.randint(0,texture_augm_range)
                    X += [[image_aug_texture[n]]]
                    y += [label]

        X = np.concatenate(X, axis=0)
        y = np.array(y)

        return X, y
    
    def augm_random_add(self, X_train, y_train):
   
        aug = tf.keras.preprocessing.image.ImageDataGenerator(
            rotation_range=20,
            zoom_range=0.15,
            width_shift_range=0.2,
            height_shift_range=0.2,
            shear_range=0.15,
            horizontal_flip=True, fill_mode="nearest")

        X,y = [],[]
        for image, label in zip(X_train, y_train):

                    # Texture
                    highB = np.array(image) + (100/255) # 1
                    highC = np.array(image) * 3         # 2
                    gray_scale_image = np.array(image)  # 3
                    _ = rgb2gray(np.array(image))
                    gray_scale_image[:,:,0], gray_scale_image[:,:,1], gray_scale_image[:,:,2] = _, _, _
                    v_min, v_max = np.percentile(np.array(image), (0.2, 99.8))  # 4
                    better_contrast = exposure.rescale_intensity(np.array(image), in_range=(v_min, v_max))
                    adjusted_gamma_image = exposure.adjust_gamma(np.array(image), gamma=0.4, gain=0.9) # 5
                    image_aug_texture = [highB, highC, gray_scale_image, better_contrast, adjusted_gamma_image] # [1,2,3,4,5]
                    texture_augm_range = len(image_aug_texture)

                    # Shape
                    shape_augm_range = 5
                    image = np.expand_dims(image, 0)
                    image_aug_shape = aug.flow(image, batch_size=1)
                    image_aug_shape = [image_aug_shape.next() for i in range(shape_augm_range)]

                    n = np.random.randint(0,shape_augm_range)
                    X += [image_aug_shape[n]]
                    y += [label]

                    n = np.random.randint(0,texture_augm_range)
                    X += [[image_aug_texture[n]]]
                    y += [label]

        X = np.concatenate(X, axis=0)
        y = np.array(y)
        return X, y

    def Augment_add_all(self, x, y, n,k):
        x = self.Reshape(x, 'First')
        x, y = self.augm_add_all (np.array(x), np.array(y),n,k)
        x = self.Reshape(x, 'Last')
        x, y = torch.tensor(x, dtype=torch.float32), torch.tensor(y, dtype=torch.float32)
        return x,y
    


    def Augment_random_add(self, x, y):
        x = self.Reshape(x, 'First')
        x, y = self.augm_random_add (np.array(x), np.array(y))
        x = self.Reshape(x, 'Last')
        x, y = torch.tensor(x, dtype=torch.float32), torch.tensor(y, dtype=torch.float32)
        return x,y

    def LeightWeight_Adapt(self, S, Y):

        # self.f=f_lta(self.f)
        # self.f.reset()
        # self.f.to(DEVICE)
        # self.f = lta_f(S, Y, self.f, max_iter = 20)#20
        self.r=r_lta(self.r.model)
        self.r.reset()
        self.r.to(DEVICE)
        self.r = lta_r(S, Y, self.r, max_iter = 20)#20


    def LC_A(self, preds, th):
            W = np.argmax(preds,axis=1)
            Conf = np.zeros((W.shape[0]))
            for i in range(W.shape[0]):
                    Conf[i] = preds[i, W[i]]
            mn,st = np.mean(Conf), np.std(Conf)
            if th == 'adj':
                th = mn # mean confidence
            else:
                th = th # fixed given value
            wlci, wmci = np.argwhere(Conf<=th).reshape(-1,), np.argwhere(Conf>th).reshape(-1,) # do more classes with 0.1*std ....
            return wlci, wmci, th

    def LC_C(self, preds):
            W = np.argmax(preds,axis=1)
            Conf = np.zeros((W.shape[0]))
            for i in range(W.shape[0]):
                    Conf[i] = preds[i, W[i]]
            mn,st = np.mean(Conf), np.std(Conf)
            th = mn + 1.5*st # incorporate st to remove anomalies
            wlci, wmci = np.argwhere(Conf<=th).reshape(-1,), np.argwhere(Conf>th).reshape(-1,)
            return wlci, wmci, th


    def Enc (self, model, X, mode):
        model.to(DEVICE)
        with torch.no_grad():
            X = torch.tensor(np.array(X, dtype = np.float32)).to(DEVICE)
            F_init = []
            begin_idx = 0
            while begin_idx < X.size(0):
                x = X[begin_idx: begin_idx + 64]
                if mode == 'Adapt':
                    F_init.append(model.adapter(model(x)).cpu())
                elif mode == 'Prior':
                    F_init.append(model(x).cpu())
                begin_idx += 64
            F_init = torch.cat(F_init)
        return F_init
    
    def Enc_Prior (self, model, X):

                X = self.Reshape(X, 'First')
                X = tf.convert_to_tensor(X, np.float32)
                X = model.predict(X)
                X = torch.tensor(X, dtype=torch.float32)
                return X

    # for more robust estim .... we augm ....the init limited S
    def LOO_A(self, data_estimate, y_estimate, data_other, y_other, n, th):
        Dists = torch.zeros((data_estimate.shape[0],n) ,dtype=torch.float32)
        for i in range (len(data_estimate)):
            loi, loy = data_estimate[i].unsqueeze(0), y_estimate[i].unsqueeze(0)# leave-out one instance
            hs = torch.cat((data_estimate[:i], data_estimate[i+1:], data_other), axis=0)
            hy = torch.cat((y_estimate[:i], y_estimate[i+1:], y_other), axis=0)
            dist = self.pd(hs, hy, loi, n)
            Dists[i] = dist
        C = F.softmax(Dists, dim=1).numpy() # propability confidences
        wlci, wmci, th = self.LC_A(C, th)
        return wlci, wmci, th

    def LOO_C(self, data_estimate, y_estimate, data_other, y_other, n):
        Dists = self.pd(data_other, y_other, data_estimate, n)
        C = F.softmax(Dists, dim=1).numpy() # propability confidences
        wlci, wmci, th = self.LC_C(C)
        return wlci, wmci, th



    def AdaptAugment (self, supp_x, supp_y, n, k, activate, mode):
        
            X_init = supp_x
            y_init = supp_y

            if activate == 'On':
                # ________________ LCA  ____________________________
                # ____ Light augment the whole init support set  
                X_augm_light, y_augm_light = self.Augment_random_add(X_init, y_init)
                # ____ vectorize images based on Lightweighted-Prior encoder
                F_augm_light = self.Enc_Prior(self.m, X_augm_light)
                F_init = self.Enc_Prior(self.m, X_init)

                # ____ Identify the indexes of the most/least conf prediction 
                # based on adj threshold (mean confidence) of ProtoNet-based estimator via LOO (Leave-One-Out)
                wlci, wmci, th = self.LOO_A(F_init, y_init, F_augm_light, y_augm_light, n, 'adj')

                X_lc, y_lc = X_init[wlci], y_init[wlci]
                X_mc, y_mc = X_init[wmci], y_init[wmci]
                print('\nLCA')
                print('lc = ', len(y_lc))
                print('mc = ', len(y_mc))
            
                # ________________________________________________________________
                # ____ Heavy augment the least conf and light augm the most conf ____
                X_augm_heavy, y_augm_heavy = self.Augment_add_all(X_lc, y_lc,n,k)
                X_augm_light_mc, y_augm_light_mc = self.Augment_random_add(X_mc, y_mc)


                # ________________ MCC  ____________________________
                F_augm_heavy = self.Enc_Prior(self.m, X_augm_heavy)
                F_augm_light_mc = self.Enc_Prior(self.m, X_augm_light_mc)
                if mode=='LCA-MCC':
                    # #remove over-conf augms, since considered as redundant/noise
                    # #we want to keep those who really give something new to the sample space
                    wlci, wmci, th = self.LOO_C(F_augm_heavy, y_augm_heavy, c((F_augm_light, F_init)), c((y_augm_light, y_init)), n)
                    print('\nLCC')
                    print('lc = ', len(wlci))
                    print('mc = ', len(wmci))
                    F_augm_heavy_cleaned, y_augm_heavy_cleaned = F_augm_heavy[wlci], y_augm_heavy[wlci]
                    X_augm_heavy_cleaned = X_augm_heavy[wlci]

                    # # ---------- Stack -------------
                    X_augm = c((X_augm_heavy_cleaned, X_augm_light_mc, X_init))
                    F_augm = c((F_augm_heavy_cleaned, F_augm_light_mc, F_init))
                    y_augm = c((y_augm_heavy_cleaned, y_augm_light_mc, y_init))
                else:
                    #### ---------- Stack -------------
                    X_augm = c((X_augm_heavy, c((X_augm_light_mc, X_init))))
                    F_augm = c((F_augm_heavy, c((F_augm_light_mc, F_init))))
                    y_augm = c((y_augm_heavy, c((y_augm_light_mc, y_init))))
                ## X_augm_heavy, y_augm_heavy = self.Augment_random_add(X_init, y_init) # self.Augment_add_all(X_init, y_init)
                ## X_augm, y_augm = c((X_augm_heavy, X_init)),  c((y_augm_heavy, y_init))

                print('\nTotal Samples: ', len(y_augm)) # compare with other augms
                return X_augm, F_augm, y_augm
            else:
                F_init = self.Enc_Prior(self.m, X_init)
                return X_init, F_init, y_init
            

    # UMAP dimensionality reduction
    def apply_umap(self, features):

        scaled_features = StandardScaler().fit_transform(features)
        umap_reducer = umap.UMAP(n_neighbors=15, min_dist=0.1, n_components=2, random_state=42)
        return umap_reducer.fit_transform(scaled_features)
    
    def plot_features(self, features, labels, title, point_size=50):
        plt.figure(figsize=(12, 8))
        plt.scatter(features[:, 0], features[:, 1], c=labels, cmap='Spectral', s=point_size)
        plt.colorbar()
        plt.title(title)
        plt.show()

    def plot_initial_rgb(self, image_tensor):
        image_np = image_tensor.permute(1, 2, 0).cpu().numpy()
        plt.imshow(image_np)
        plt.show()

    def min_max_normalize(self, tensor):
            tensor = tensor - tensor.min()
            tensor = tensor / tensor.max()
            return tensor
    
    def find_closest(self, Y, E, I):
            class1_label = 0
            class2_label = 1
            class1_indices = np.where(Y == class1_label)[0]
            class1_points = E[class1_indices, :]
            class1_images = I[class1_indices, :]
            class2_indices = np.where(Y == class2_label)[0]
            class2_points = E[class2_indices, :]
            class2_images = I[class2_indices, :]
            distances = np.sqrt(((class1_points[:, np.newaxis, :] - class2_points[np.newaxis, :, :]) ** 2).sum(axis=2))
            min_distance_idx = np.unravel_index(np.argmin(distances, axis=None), distances.shape)
            closest_class1_idx, closest_class2_idx = min_distance_idx
            closest_image_class1 = class1_images[closest_class1_idx]
            closest_image_class2 = class2_images[closest_class2_idx]
            return closest_image_class1, closest_image_class2
    
    def ProtoNet_Prior_Adapt(self,s, Ps, y, q, n):
        with torch.no_grad():
            # Ps: 'Prior Support embeding' # Already extracted from prior-encoder from AdaptAugment to save time
            Pq = self.Enc_Prior (self.m, q) #'Prior Query embeding'

            s, q = resize_tensor(s), resize_tensor(q)
            As, Aq = self.Enc(self.r, s, 'Adapt'), self.Enc(self.r, q, 'Adapt')

        return self.pd(c((As, Ps),1), y, c((Aq, Pq),1), n)


    def compute_prototypes(self, embeddings, labels, n_way):
        prots = torch.zeros(n_way, embeddings.shape[-1]).type(
            embeddings.dtype).to(embeddings.device)
        for i in range(n_way):
            if torch.__version__.startswith('1.1'):
                prots[i] = embeddings[(labels == i).nonzero(), :].mean(0)
            else:
                prots[i] = embeddings[(labels == i).nonzero(as_tuple=False), :].mean(0)
        return prots


    def pd(self, S, Y, Q, n):# Prototype Distance
        #### prots = self.compute_prototypes(S, Y, n).unsqueeze(0)
        model = GaussianModel(n, S.device, Y)
        model.compute_prototypes(S, Y)
        alpha=0.1
        optim = MAP(alpha, Y)
        n_epochs = 10
        prob, _ = optim.loop(model, Q, n_epochs, None)
        prots = model.estimateFromMask(Q, prob)

        embeds = Q.unsqueeze(1)
        dist = F.cosine_similarity(embeds, prots, dim=-1, eps=1e-30)

        return dist

    def EMD(self,T_dist, q, n): # Earth Mover's Distance
        n_usamples=q.size(0)
        cosine_distance= 1-T_dist
        cosine_distance=cosine_distance.cpu().numpy()
        preds=ot.emd(np.ones(n_usamples)/n_usamples,np.ones(n)/n,cosine_distance) # ref as: type scholar Earth Mover's Distance (EMD) few shot learning
        return preds





    def predict(self, query_set: torch.Tensor) -> np.ndarray:


        q = query_set
        s, y, n, k = self.other

        # ---------------------- Prediction Framework ----------------------------------
        s, Ps, y = self.AdaptAugment(s, y, n, k, 'On', mode='LCA-MCC') #'LCA'
        self.LeightWeight_Adapt(s, y) # learn task adaptation modules on the support set
        T_dist = self.ProtoNet_Prior_Adapt(s, Ps, y, q, n) # extract prototype-base distance via the combined prior and adapted based embeddings
        preds = self.EMD(T_dist, q, n) # # ref as: type scholar Earth Mover's Distance (EMD) few shot learning
        # ------------------------------------------------------------------------------

        return preds
