
import pickle
import time
import random

TIME_LIMIT = 1 # time limit of the whole process in seconds   4500
TIME_TRAIN = TIME_LIMIT - 30*60 # set aside 30min for test
t1 = time.time()

import os
import torch
import torch.nn as nn


from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import MinMaxScaler
from sklearn.pipeline import Pipeline
from skimage.color import rgb2gray


try:
    import numpy as np
except:
    os.system("pip install numpy")

try:
    import cython
except:
    os.system("pip install cython")

try:
    import ot
except:
    os.system("pip install POT")

try:
    import tqdm
except:
    os.system("pip install tqdm")

try:
    import timm
except:
    os.system("pip install timm")



from utils import get_logger, timer, resize_tensor, augment, decode_label, mean
from api import MetaLearner, Learner, Predictor
from backbone import MLP, rn_timm_mix, Wrapper
from torch import optim
import torch.nn.functional as F
from typing import Iterable, Any, Tuple, List
from skimage.transform import rescale, resize
import tensorflow as tf
import keras

from tensorflow.keras.applications.mobilenet import MobileNet
from tensorflow.keras.layers import GlobalAveragePooling2D



from skimage import exposure
import timm






LOGGER = get_logger('GLOBAL')
DEVICE = torch.device('cuda') # cpu cuda

class MyMetaLearner(MetaLearner):

    def __init__(self, 
                 train_classes: int, 
                 total_classes: int,
                 logger: Any) -> None:

        super().__init__(train_classes, total_classes, logger)
        
        self.timer = timer()
        self.timer.initialize(time.time(), TIME_TRAIN - time.time() + t1)
        self.timer.begin('load pretrained model')
        self.model = Wrapper(rn_timm_mix(True, 'resnet200d', 0.1)).to(DEVICE) # resnet200d  seresnet152d
        
        times = self.timer.end('load pretrained model')
        LOGGER.info('current model', self.model)
        LOGGER.info('load time', times, 's')
        self.dim = 2048

        # only optimize the last 2 layers
        backbone_parameters = []
        backbone_parameters.extend(self.model.set_get_trainable_parameters([3, 4]))
        # set learnable layers
        self.model.set_learnable_layers([3, 4])
        self.cls = MLP(self.dim, train_classes).to(DEVICE)
        self.opt = optim.Adam(
            [
                {"params": backbone_parameters},
                {"params": self.cls.parameters(), "lr": 1e-3}
            ], lr=1e-4
        )

    def meta_fit(self, 
                 meta_train_generator: Iterable[Any],
                 meta_valid_generator: Iterable[Any]) -> Learner:

        valid_task = []
        for task in meta_valid_generator(1): # 50
            supp_x, supp_y = task.support_set[0], task.support_set[1]
            quer_x, quer_y = task.query_set[0], task.query_set[1]
            supp_x = supp_x[supp_y.sort()[1]]
            supp_end = supp_x.size(0)
            valid_task.append([torch.cat([supp_x, quer_x]), quer_y])

        with torch.no_grad():
            self.model.set_mode(False)
            acc_valid = 0
            for x, quer_y in valid_task:
                x = x.to(DEVICE)
                x = self.model(x)
                supp_x, quer_x = x[:supp_end], x[supp_end:]

                supp_x = supp_x.view(5, 5, supp_x.size(-1))
                logit = decode_label(supp_x, quer_x).cpu().numpy()
                acc_valid += (logit.argmax(1) == np.array(quer_y)).mean()
            acc_valid /= len(valid_task)

        return MyLearner(self.model.cpu())


class MyLearner(Learner):

    def __init__(self, model: Wrapper = None) -> None:

        super().__init__()
        self.model = model

    @torch.no_grad()
    def fit(self, support_set: Tuple[torch.Tensor, torch.Tensor, torch.Tensor, 
                               int, int]) -> Predictor:

        self.model.to(DEVICE)
        X_train, y_train, _, n, k = support_set
        X_train, y_train = X_train, y_train
        
        return MyPredictor(self.model, X_train, y_train, n, k)

    def save(self, path_to_save: str) -> None:

        torch.save(self.model, os.path.join(path_to_save, "model.pt"))
 
    def load(self, path_to_load: str) -> None:

        if self.model is None:
            self.model = torch.load(os.path.join(path_to_load, 'model.pt'))



# ------------------------------------
class Model(nn.Module):
    def __init__(self, name, *, in_chans = 2, pretrained=True):
        """
        name (str): timm model name, e.g. tf_efficientnet_b2_ns
        """
        super().__init__()

        # Use timm
        #model = timm.create_model(name, pretrained=pretrained, in_chans=in_chans)
        model = timm.create_model(name, pretrained=pretrained)

        clsf = model.default_cfg['classifier']
        n_features = model._modules[clsf].in_features
        model._modules[clsf] = nn.Identity()

        #self.fc = nn.Linear(n_features, 1)
        self.model = model

    def forward(self, x):
        x = self.model(x)
        #x = self.fc(x)
        return x
# ------------------------------------









    
class MyPredictor(Predictor):

    def __init__(self, 
                 model: Wrapper, 
                 supp_x: torch.Tensor, 
                 supp_y: torch.Tensor, 
                 n: int, 
                 k: int) -> None:

        super().__init__()
        self.model = model
        self.other = [supp_x, supp_y, n, k]

    def pipeline_LR(self, X_train, y_train):
        estimators = [
            ('scaler', MinMaxScaler()),
            ('clf', LogisticRegression(max_iter=1000, random_state=42))
            ]
        pipe = Pipeline(estimators)
        pipe.fit(X_train, y_train)
        return pipe


    def Reshape(self, _X, channels_order):
        if channels_order == 'First':
            np_X = np.array (_X)
            resh_X = np.zeros((np_X.shape[0],np_X.shape[2],np_X.shape[3],3))
            resh_X[:,:,:,0], resh_X[:,:,:,1], resh_X[:,:,:,2] = np_X[:, 0], np_X[:, 1], np_X[:, 2]
            ###_X = tf.convert_to_tensor(resh_X, np.float32)
        elif channels_order == 'Last':
            np_X = np.array (_X)
            resh_X = np.zeros((np_X.shape[0], 3, np_X.shape[1],np_X.shape[2]))
            resh_X[:,0,:,:], resh_X[:,1,:,:], resh_X[:,2,:,:] = np_X[:,:,:,0], np_X[:,:,:,1], np_X[:,:,:,2]
            ###_X = tf.convert_to_tensor(resh_X, np.float32)
        return resh_X


    def augm_add_all(self, X_train, y_train):
   
        aug = tf.keras.preprocessing.image.ImageDataGenerator(
            rotation_range=20,
            zoom_range=0.15,
            width_shift_range=0.2,
            height_shift_range=0.2,
            shear_range=0.15,
            horizontal_flip=True, fill_mode="nearest")

        X,y = [],[]
        for image, label in zip(X_train, y_train):

                    # # Texture
                    # highB = np.array(image) + (100/255) # 1
                    # highC = np.array(image) * 3         # 2
                    # gray_scale_image = np.array(image)  # 3
                    # _ = rgb2gray(np.array(image))
                    # gray_scale_image[:,:,0], gray_scale_image[:,:,1], gray_scale_image[:,:,2] = _, _, _
                    # v_min, v_max = np.percentile(np.array(image), (0.2, 99.8))  # 4
                    # better_contrast = exposure.rescale_intensity(np.array(image), in_range=(v_min, v_max))
                    # adjusted_gamma_image = exposure.adjust_gamma(np.array(image), gamma=0.4, gain=0.9) # 5
                    # image_aug_texture = [highB, highC, gray_scale_image, better_contrast, adjusted_gamma_image] # [1,2,3,4,5]

                    # Shape
                    cnt = 5
                    image = np.expand_dims(image, 0)
                    image_aug_shape = aug.flow(image, batch_size=1)
                    aux_image = [image_aug_shape.next() for i in range(cnt)]

                    cnt2 = 0 
                    # for _im_tran in image_aug_texture:
                    #     cnt2 += 1
                    #     aux_image = aux_image + [np.expand_dims(_im_tran, 0)]

                    naug = cnt+cnt2
                    aux_label = (naug)*[label]

                    for _im, _l in zip(aux_image, aux_label):
                        X += [_im]
                        y += [_l]
        
        X = np.concatenate(X, axis=0)
        y = np.array(y)
        return X, y

    def augm_random_add(self, X_train, y_train):
   
        aug = tf.keras.preprocessing.image.ImageDataGenerator(
            rotation_range=20,
            zoom_range=0.15,
            width_shift_range=0.2,
            height_shift_range=0.2,
            shear_range=0.15,
            horizontal_flip=True, fill_mode="nearest")

        X,y = [],[]
        for image, label in zip(X_train, y_train):

                    # Texture
                    # highB = np.array(image) + (100/255) # 1
                    # highC = np.array(image) * 3         # 2
                    # gray_scale_image = np.array(image)  # 3
                    # _ = rgb2gray(np.array(image))
                    # gray_scale_image[:,:,0], gray_scale_image[:,:,1], gray_scale_image[:,:,2] = _, _, _
                    # v_min, v_max = np.percentile(np.array(image), (0.2, 99.8))  # 4
                    # better_contrast = exposure.rescale_intensity(np.array(image), in_range=(v_min, v_max))
                    # adjusted_gamma_image = exposure.adjust_gamma(np.array(image), gamma=0.4, gain=0.9) # 5
                    # image_aug_texture = [highB, highC, gray_scale_image, better_contrast, adjusted_gamma_image] # [1,2,3,4,5]

                    # Shape
                    cnt = 5
                    image = np.expand_dims(image, 0)
                    image_aug_shape = aug.flow(image, batch_size=1)
                    aux_image = [image_aug_shape.next() for i in range(cnt)]

                    cnt2 = 0 
                    # for _im_tran in image_aug_texture:
                    #     cnt2 += 1
                    #     aux_image = aux_image + [np.expand_dims(_im_tran, 0)]

                    naug = cnt+cnt2
                    aux_label = (naug)*[label]

                    n = np.random.randint(0,naug)
                    X += [aux_image[n]]
                    y += [aux_label[n]]

                    n = np.random.randint(0,naug)
                    X += [aux_image[n]]
                    y += [aux_label[n]]

        X = np.concatenate(X, axis=0)
        y = np.array(y)
        return X, y

    def Augment_add_all(self, x, y):
        x = self.Reshape(x, 'First')
        x, y = self.augm_add_all (np.array(x), np.array(y))
        x = self.Reshape(x, 'Last')
        ##x, y = torch.from_numpy(np.array(x)), torch.from_numpy(np.array(y))
        return x,y

    def Augment_random_add(self, x, y):
        x = self.Reshape(x, 'First')
        x, y = self.augm_random_add (np.array(x), np.array(y))
        x = self.Reshape(x, 'Last')
        ##x, y = torch.from_numpy(np.array(x)), torch.from_numpy(np.array(y))
        return x,y

    def LC(self, preds, mode):
            W = np.argmax(preds,axis=1)
            Conf = np.zeros((W.shape[0]))
            for i in range(W.shape[0]):
                    Conf[i] = preds[i, W[i]]
            mn,st = np.mean(Conf), np.std(Conf)
            if mode == 'adj':
                th = mn ###- (st*0.1)
            else:
                th = mode
            wlci, wmci = np.argwhere(Conf<=th).reshape(-1,), np.argwhere(Conf>th).reshape(-1,) # do more classes with 0.1*std ....
            return wlci, wmci, th

    def Torch_Encoder (self, model, X):
        X = torch.tensor(np.array(X, dtype = np.float32)).to(DEVICE)
        F_init = []
        begin_idx = 0
        while begin_idx < X.size(0):
            x = X[begin_idx: begin_idx + 64]
            F_init.append(model(x).cpu())# .to(DEVICE) .cpu()#F_init.append(self.model(x).to(DEVICE))# .to(DEVICE) .cpu()
            begin_idx += 64
        F_init = torch.cat(F_init)
        F_init = F_init.numpy()
        return F_init

    def TF_Encoder (self, model, X):

                X = self.Reshape(X, 'First')
                X = tf.convert_to_tensor(X, np.float32)
                X = model.predict(X)
                return X

    def LCA (self, model, supp_x, supp_y, query_set):
        
            X_init = supp_x
            y_init = supp_y
            # ________________ Estimation of Confidences ____________________________
            # ____ Light augment the whole init support set  
            X_augm_light, y_augm_light = self.Augment_random_add(X_init, y_init)
            # ____ vectorize images based on CNN encoder
            F_augm_light = self.TF_Encoder(model, X_augm_light) #self.Torch_Encoder(model, X_augm_light)#
            F_init = self.TF_Encoder(model, X_init) #self.Torch_Encoder(model, X_init)#

            F_augm_light_full = np.concatenate((F_init, F_augm_light),axis=0)
            y_augm_light_full = np.concatenate((y_init, y_augm_light),axis=0)

            # ____ Fit LR models in a OVA pipeliney[]
            ovalr = self.pipeline_LR(np.array(F_augm_light_full), np.array(y_augm_light_full))
            # extract propabilities for each instance
            preds = ovalr.predict_proba(F_init)
            # ____ Identify the indexes of the most-least conf prediction 
            # based on adj threshold (mean confidence of LR model)
            wlci, wmci, th = self.LC(preds, 'adj')
            X_lc, y_lc = X_init[wlci], y_init[wlci]
            X_mc, y_mc = X_init[wmci], y_init[wmci]
            ###F_lc = F_init[wlci]
            print('')
            print('lc = ', len(y_lc))
            print('mc = ', len(y_mc))
            # ________________________________________________________________
            # ____ Heavy augment the most conf and light augm the less conf ____
            X_augm_heavy, y_augm_heavy = self.Augment_add_all(X_lc, y_lc) 
            ###X_augm_l, y_augm_l = self.Augment_random_add(X_mc, y_mc)
            ##X_augm = np.concatenate((X_augm_h, X_augm_l), axis = 0)
            ##y_augm = np.concatenate((y_augm_h, y_augm_l), axis = 0)
            # __________________________________________________________________
            F_augm_heavy = self.TF_Encoder(model, X_augm_heavy)#self.Torch_Encoder(model, X_augm_heavy) #
            F_query = self.TF_Encoder(model, query_set)#self.Torch_Encoder(model, query_set) #

            supp_x =  np.concatenate((F_augm_light_full, F_augm_heavy),axis=0)# F_init#
            supp_y =  np.concatenate((y_augm_light_full, y_augm_heavy),axis=0)# y_init#


            quer_x = F_query

            return supp_x, supp_y, quer_x







    @torch.no_grad()
    def predict(self, query_set: torch.Tensor) -> np.ndarray:


        baseline = tf.keras.applications.mobilenet.MobileNet(include_top=False, input_shape=(128, 128, 3), weights="imagenet")
        model = tf.keras.models.Model(inputs=baseline.inputs, outputs=tf.keras.layers.GlobalAveragePooling2D()(baseline.layers[-1].output))

        


        ######model = Model('resnest14d', pretrained=True, in_chans = 3).to(DEVICE)
        #model = Model('inception_v4', pretrained=True).to(DEVICE).eval() 
        # tf_efficientnet_b8, efficientnet_b0  inception_v4  resnest14d tf_efficientnet_b7_ns densenet201

        query_set = query_set
        supp_x, supp_y, n, k = self.other

        supp_x, supp_y, quer_x = self.LCA(model, supp_x, supp_y, query_set) # <<<<<<<<<<

        preds = self.pipeline_LR(np.array(supp_x), np.array(supp_y)).predict_proba(quer_x)

        return preds







