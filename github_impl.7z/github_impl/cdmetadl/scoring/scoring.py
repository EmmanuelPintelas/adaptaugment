""" This is the scoring program written by the organizers. This program also
runs on the Cross-Domain MetaDL competition platform to test your code.

Usage: 

python -m cdmetadl.scoring.scoring \
    --results_dir=output_dir_ingestion \
    --input_data_dir=input_dir \
    --output_dir_scoring=output_dir

* The results directory output_dir_ingestion (e.g. ../../ingestion_output) must
be the directory containing the output from the ingestion program with the 
following files:
    metadata_ingestion
    experimental_settings.txt
	task_{task_id}.predict
 
* The input directory input_dir (e.g. ../../public_data) contains several 
datasets formatted following this instructions: 
https://github.com/ihsaan-ullah/meta-album/tree/master/DataFormat

* The output directory output_dir (e.g. ../../scoring_output) will store the 
computed scores

AS A PARTICIPANT, DO NOT MODIFY THIS CODE.
"""
import os
import datetime
import jinja2
from sys import exit, version
from absl import app, flags

from cdmetadl.helpers.scoring_helpers import *
from cdmetadl.helpers.general_helpers import *
from cdmetadl.ingestion.image_dataset import create_datasets
from cdmetadl.ingestion.data_generator import CompetitionDataLoader

# =============================== BEGIN OPTIONS ===============================
FLAGS = flags.FLAGS

# Random seed
# Any int to be used as random seed for reproducibility
flags.DEFINE_integer("seed", 93, "Random seed.")

# Verbose mode 
# True: show various progression messages (recommended value)
# False: no progression messages are shown
flags.DEFINE_boolean("verbose", True, "Verbose mode.")

# Debug mode
# 0: no debug 
# 1: compute additional scores (recommended value)
# 2: same as 1 + show the Python version and list the directories 
flags.DEFINE_integer("debug_mode", 1, "Debug mode.")

# Private information
# True: the name of the datasets is kept private
# False: all the information is shown (recommended value)
flags.DEFINE_boolean("private_information", False, "Private information flag.")

# Overwrite results flag
# True: the previous output directory is overwritten
# False: the previous output directory is renamed (recommended value)
flags.DEFINE_boolean("overwrite_previous_results", False, 
    "Overwrite results flag.")

# Tesk tasks per dataset
# The total number of test tasks will be num_datasets x test_tasks_per_dataset
flags.DEFINE_integer("test_tasks_per_dataset", 100, 
    "Number of test tasks per dataset.")

# Default location of directories
# If no arguments to scoring.py are provided, these are the directories used. 
flags.DEFINE_string("input_data_dir", "../../public_data", "Path to the " 
    + "directory containing the meta_train and meta_test data.")
flags.DEFINE_string("results_dir","../../ingestion_output", 
    "Path to the output directory for the ingestion program.")
flags.DEFINE_string("output_dir_scoring", "../../scoring_output", 
    "Path to the ourput directory for the scoring program.")

# =============================================================================
# =========================== END USER OPTIONS ================================
# =============================================================================

# Program version
VERSION = 1.1

def scoring(argv) -> None:
    del argv
    
    SEED = FLAGS.seed
    VERBOSE = FLAGS.verbose
    DEBUG_MODE = FLAGS.debug_mode
    PRIVATE_INFORMATION = FLAGS.private_information
    OVERWRITE_PREVIOUS_RESULTS = FLAGS.overwrite_previous_results
    TEST_TASKS_PER_DATASET = FLAGS.test_tasks_per_dataset
    
    vprint(f"Scoring program version: {VERSION}", VERBOSE)
    vprint(f"Using random seed: {SEED}", VERBOSE)
    
    # Define the path to the directory
    results_dir = os.path.abspath(FLAGS.results_dir)
    ref_dir = os.path.abspath(FLAGS.input_data_dir) 
    output_dir = os.path.abspath(FLAGS.output_dir_scoring)
    
    # Show python version and directory structure
    if DEBUG_MODE > 1: 
        print(f"\nPython version: {version}")
        print(f"Using results_dir: {results_dir}")
        print(f"Using output_dir: {output_dir}")
        show_dir(".")
    
    vprint(f"\n{'#'*60}\n{'#'*18} Scoring program starts {'#'*18}\n{'#'*60}\n", 
        VERBOSE)
    
    # Check all the required directories
    vprint("\nChecking directories...", VERBOSE)
    exist_dir(results_dir)
    vprint("[+] Directories", VERBOSE)
    
    # Prepare test generator to access test tasks
    vprint("\nPreparing datasets info...", VERBOSE)
    _, _, test_datasets_info = prepare_datasets_information(ref_dir, 0, SEED, 
        VERBOSE, True)
    vprint("[+] Datasets info", VERBOSE)
    
    vprint("\nInitializing test generator...", VERBOSE)
    test_generator_config = {
        "N": None,
        "min_N": 2,
        "max_N": 20,
        "k": None,
        "min_k": 1,
        "max_k": 20,
        "query_images_per_class": 20
    }
    test_datasets = create_datasets(test_datasets_info)
    test_loader = CompetitionDataLoader(datasets=test_datasets, 
        episodes_config=test_generator_config, seed=SEED, 
        private_info=PRIVATE_INFORMATION, test_generator=True, verbose=VERBOSE)
    meta_test_generator = test_loader.generator
    vprint("[+] Data generator", VERBOSE)
    
    vprint("\nChecking ingestion output...", VERBOSE)
    result_files = os.listdir(results_dir)
    number_of_tasks = sum(".predict" in file for file in result_files)
    if number_of_tasks != len(test_datasets) * TEST_TASKS_PER_DATASET: 
        print(f"[-] There are no enough results in {results_dir}")
        exit(1)
    vprint("\n[+] Ingestion output", VERBOSE)
    
    # Compute scores
    vprint("\nComputing scores...", VERBOSE)
    # Compute the score for each task
    if DEBUG_MODE < 1:
        # Read metric and count the number of tasks
        curr_dir_path = os.path.dirname(os.path.realpath(__file__))
        score_file = os.path.join(curr_dir_path, "scores.txt")
        score_name, scoring_function = get_score(score_file)
        main_score = score_name
        vprint(f"\tUsing score: {score_name}", VERBOSE)
    else:
        main_score = "Normalized Accuracy"
        vprint(f"\tUsing scores: Accuracy, Macro F1 Score, Macro Precision, "
            + f"Macro Recall", VERBOSE)
        
    scores = dict()
    scores_per_dataset = dict()
    scores_per_ways = dict()
    scores_per_shots = dict()
    tasks = list()
    for i, task in enumerate(meta_test_generator(TEST_TASKS_PER_DATASET)):
        vprint(f"\tTask {i} started...", VERBOSE)
        
        # Extract task information
        y_true = task.query_set[1].numpy()
        task_dataset = task.dataset
        task_ways = task.num_ways
        task_shots = task.num_shots
        
        # Load ground truth and predicted labels
        task_name = f"{results_dir}/task_{i+1}"
        y_pred = read_results_file(f"{task_name}.predict")

        task_scores = compute_all_scores(y_true, y_pred, task_ways)
        keys = list(task_scores.keys())

        for key in keys:
            if key not in scores:
                scores[key] = list()
            current_score = task_scores[key]
            scores[key].append(current_score)
        print(scores['Accuracy'])
            
    scores_names = list(scores.keys())
    for i, score_name in enumerate(scores_names):
        overall_score, overall_ci = mean_confidence_interval(scores[score_name])
        print(score_name+': ',np.round(overall_score,3))







if __name__ == "__main__":
    app.run(scoring)
    