""" Combine the ingestion and scoring processes. 

Usage: 
    python -m cdmetadl.run \
        --input_data_dir=../public_data \
        --submission_dir=../baselines/random \
        --overwrite_previous_results=True \
        --test_tasks_per_dataset=10
    

"""

from shlex import split
from subprocess import call
from absl import app, flags

import tensorflow as tf
import keras





FLAGS = flags.FLAGS

flags.DEFINE_integer("seed", 93, "Random seed.")

flags.DEFINE_boolean("verbose", True, "Verbose mode.")

flags.DEFINE_integer("debug_mode", 1, "Debug mode.")

flags.DEFINE_integer("image_size", 128, "Image size.")

flags.DEFINE_integer("max_time", 10000000000000000000000000, 
    "Maximum time in seconds per testing task.")

flags.DEFINE_boolean("overwrite_previous_results", False, 
    "Overwrite results flag.")

flags.DEFINE_integer("test_tasks_per_dataset", 100, #<<<<<<<   
    "Number of test tasks per dataset.")

flags.DEFINE_boolean("private_information", False, "Private information flag.")

# it is tested on data B/A and trained on A/B respectivelly.
flags.DEFINE_string("input_data_dir", "public_data_A", "Path to the directory"# #<<<<<<<  public_data_A  public_data_B
    + " containing the meta_train and meta_test data.")

flags.DEFINE_string("output_dir_ingestion","../ingestion_output", 
    "Path to the output directory for the ingestion program.")

flags.DEFINE_string("submission_dir","baselines/lca_proposed", #<<<<<<< metadelta  maml protonet matchingnet finetuning  lca_proposed   
    "Path to the directory containing the solution to use.")

flags.DEFINE_string("output_dir_scoring", "../scoring_output", 
    "Path to the ourput directory for the scoring program.")


def main(argv) -> None:
    """ Runs the ingestion and scoring programs sequentially, as they are 
    handled in CodaLab.
    """
    del argv
    
    seed = FLAGS.seed
    verbose = FLAGS.verbose
    debug_mode = FLAGS.debug_mode
    image_size = FLAGS.image_size
    max_time = FLAGS.max_time
    overwrite_previous_results = FLAGS.overwrite_previous_results
    test_tasks_per_dataset = FLAGS.test_tasks_per_dataset
    private_information = FLAGS.private_information
    input_data_dir = FLAGS.input_data_dir
    output_dir_ingestion = FLAGS.output_dir_ingestion
    submission_dir = FLAGS.submission_dir
    output_dir_scoring = FLAGS.output_dir_scoring
    
    command_ingestion = "python -m cdmetadl.ingestion.ingestion " \
        + f"--seed={seed} " \
        + f"--verbose={verbose} " \
        + f"--debug_mode={debug_mode} " \
        + f"--image_size={image_size} " \
        + f"--overwrite_previous_results={overwrite_previous_results} " \
        + f"--max_time={max_time} " \
        + f"--test_tasks_per_dataset={test_tasks_per_dataset} " \
        + f"--input_data_dir={input_data_dir} " \
        + f"--output_dir_ingestion={output_dir_ingestion} " \
        + f"--submission_dir={submission_dir}"

    command_scoring = "python -m cdmetadl.scoring.scoring " \
        + f"--seed={seed} " \
        + f"--verbose={verbose} " \
        + f"--debug_mode={debug_mode} " \
        + f"--private_information={private_information} " \
        + f"--overwrite_previous_results={overwrite_previous_results} " \
        + f"--test_tasks_per_dataset={test_tasks_per_dataset} " \
        + f"--input_data_dir={input_data_dir} " \
        + f"--results_dir={output_dir_ingestion} " \
        + f"--output_dir_scoring={output_dir_scoring}"
        
    cmd_ing = split(command_ingestion)
    cmd_sco = split(command_scoring)
    
    call(cmd_ing)
    call(cmd_sco)


if __name__ == "__main__":
    app.run(main)








# -------------- DATA A --------------

# MAML SWICH WITH FT
# Normalized Accuracy:  0.385
# Accuracy:  0.441
# Macro F1 Score:  0.428
# Macro Precision:  0.442
# Macro Recall:  0.441

# PROTONET
# Normalized Accuracy:  0.617
# Accuracy:  0.655
# Macro F1 Score:  0.653
# Macro Precision:  0.669
# Macro Recall:  0.655

# MATCHINGNET
# Normalized Accuracy:  0.387
# Accuracy:  0.451
# Macro F1 Score:  0.411
# Macro Precision:  0.481
# Macro Recall:  0.451

# -------------- DATA B --------------

# METADELTA
# Normalized Accuracy:  0.645
# Accuracy:  0.679
# Macro F1 Score:  0.679
# Macro Precision:  0.679
# Macro Recall:  0.679

# MAML 
# Normalized Accuracy:  0.217
# Accuracy:  0.302
# Macro F1 Score:  0.291
# Macro Precision:  0.299
# Macro Recall:  0.302

# PROTONET
# Normalized Accuracy:  0.439
# Accuracy:  0.501
# Macro F1 Score:  0.499
# Macro Precision:  0.519
# Macro Recall:  0.501

# MATCHINGNET
# Normalized Accuracy:  0.22
# Accuracy:  0.311
# Macro F1 Score:  0.282
# Macro Precision:  0.306
# Macro Recall:  0.311

# FT
# Normalized Accuracy:  0.299
# Accuracy:  0.378
# Macro F1 Score:  0.355
# Macro Precision:  0.396
# Macro Recall:  0.378


# lca_proposed
# Normalized Accuracy:  0.741
# Accuracy:  0.765
# Macro F1 Score:  0.764
# Macro Precision:  0.777
# Macro Recall:  0.765


# random_add
# Normalized Accuracy:  0.74
# Accuracy:  0.764
# Macro F1 Score:  0.763
# Macro Precision:  0.775
# Macro Recall:  0.764

# add_all
# Normalized Accuracy:  0.744
# Accuracy:  0.768
# Macro F1 Score:  0.766
# Macro Precision:  0.778
# Macro Recall:  0.768

